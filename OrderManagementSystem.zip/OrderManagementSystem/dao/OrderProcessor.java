package dao;

import java.sql.*;
import java.util.*;
import entity.*;
import exception.*;

import util.DBConnUtil;

public class OrderProcessor implements IOrderManagementRepository {

    @Override
    public void createOrder(User user, List<Product> products) throws Exception {
        // Logic to create order
        System.out.println("Order created for user: " + user.getUsername());
    }

    @Override
    public void cancelOrder(int userId, int orderId) throws Exception {
        // Logic to cancel order
        System.out.println("Order with ID " + orderId + " cancelled for user ID: " + userId);
    }

    @Override
    public void createProduct(User user, Product product) throws Exception {
        if (!"Admin".equalsIgnoreCase(user.getRole())) {
            throw new UserNotFoundException("Only Admin can create products.");
        }
        System.out.println("Product created: " + product.getProductName());
    }

    @Override
    public void createUser(User user) throws Exception {
        System.out.println("User created: " + user.getUsername());
    }

    @Override
    public List<Product> getAllProducts() throws Exception {
        System.out.println("Getting all products...");
        return new ArrayList<>(); // dummy
    }

    @Override
    public List<Product> getOrderByUser(User user) throws Exception {
        System.out.println("Getting orders for user: " + user.getUsername());
        return new ArrayList<>(); // dummy
    }
}
