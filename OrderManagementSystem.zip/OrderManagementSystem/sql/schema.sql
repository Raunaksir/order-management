CREATE DATABASE IF NOT EXISTS order_management_system;
USE order_management_system;

CREATE TABLE IF NOT EXISTS user (
    userId INT PRIMARY KEY,
    username VARCHAR(255),
    password VARCHAR(255),
    role VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS product (
    productId INT PRIMARY KEY,
    productName VARCHAR(255),
    description TEXT,
    price DOUBLE,
    quantityInStock INT,
    type VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS orders (
    orderId INT AUTO_INCREMENT PRIMARY KEY,
    userId INT,
    productId INT,
    quantity INT,
    FOREIGN KEY (userId) REFERENCES user(userId),
    FOREIGN KEY (productId) REFERENCES product(productId)
);

-- Sample Insertions
INSERT INTO user VALUES (1, 'admin', 'admin123', 'Admin');
INSERT INTO product VALUES (101, 'Smartphone', 'Android Phone', 20000, 50, 'Electronics');