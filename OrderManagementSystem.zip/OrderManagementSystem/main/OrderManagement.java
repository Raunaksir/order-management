package main;

import dao.OrderProcessor;
import entity.User;
import entity.Product;

import java.util.*;

public class OrderManagement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        OrderProcessor orderProcessor = new OrderProcessor();

        while (true) {
            System.out.println("\n1. Create User\n2. Create Product\n3. Cancel Order\n4. Get All Products\n5. Get Orders by User\n6. Exit");
            int choice = sc.nextInt();
            sc.nextLine();

            try {
                switch (choice) {
                    case 1:
                        // create user
                        break;
                    case 2:
                        // create product
                        break;
                    case 3:
                        // cancel order
                        break;
                    case 4:
                        // get all products
                        break;
                    case 5:
                        // get orders by user
                        break;
                    case 6:
                        System.out.println("Thank you!");
                        sc.close();
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice!");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
