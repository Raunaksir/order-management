CREATE DATABASE IF NOT EXISTS order_management_db;
USE order_management_db;

CREATE TABLE IF NOT EXISTS Users (
    userId INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(10) NOT NULL
);

CREATE TABLE IF NOT EXISTS Products (
    productId INT PRIMARY KEY AUTO_INCREMENT,
    productName VARCHAR(100),
    description TEXT,
    price DOUBLE,
    quantityInStock INT,
    type VARCHAR(20),
    brand VARCHAR(50),
    warrantyPeriod INT,
    size VARCHAR(10),
    color VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS Orders (
    orderId INT PRIMARY KEY AUTO_INCREMENT,
    userId INT,
    orderDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES Users(userId)
);

CREATE TABLE IF NOT EXISTS Order_Products (
    orderProductId INT PRIMARY KEY AUTO_INCREMENT,
    orderId INT,
    productId INT,
    quantity INT,
    FOREIGN KEY (orderId) REFERENCES Orders(orderId),
    FOREIGN KEY (productId) REFERENCES Products(productId)
);