package entity;

public class User {
    private int userId;
    private String username;
    private String password;
    private String role; // Admin/User

    public User() {}

    public User(int userId, String username, String password, String role) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    // Getters and Setters
}