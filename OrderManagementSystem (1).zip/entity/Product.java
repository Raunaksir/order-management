package entity;

public class Product {
    protected int productId;
    protected String productName;
    protected String description;
    protected double price;
    protected int quantityInStock;
    protected String type; // Electronics/Clothing

    public Product() {}

    public Product(int productId, String productName, String description, double price, int quantityInStock, String type) {
        this.productId = productId;
        this.productName = productName;
        this.description = description;
        this.price = price;
        this.quantityInStock = quantityInStock;
        this.type = type;
    }

    // Getters and Setters
}